# -*- coding: utf-8 -*-
# 1. Пончики

count = 22

if count >= 10:
    print('Кількість пончиків: багато')
else:
    print('Кількість пончиків:', count)
