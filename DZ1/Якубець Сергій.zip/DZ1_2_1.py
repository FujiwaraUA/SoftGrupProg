# -*- coding: utf-8 -*-
# 1. Парні

s = 'a b c d e f'
s1 = s[2::4]
