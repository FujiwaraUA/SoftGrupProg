# -*- coding: utf-8 -*-
# 2. Навпаки

s = 'a b c d e'
s1 = s[::-1]
