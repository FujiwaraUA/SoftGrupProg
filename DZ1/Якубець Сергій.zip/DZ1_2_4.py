# -*- coding: utf-8 -*-
# 4. Паліндром

chislo = 121
print('Паліндром') if str(chislo) == str(chislo)[::-1] else print('Не паліндром')
