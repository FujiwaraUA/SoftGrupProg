# -*- coding: utf-8 -*-
# 13. Унікальний набір

list1 = [1, 2, 3, 1, 'dfsf', 0, 3, 3, 2]
print(set(list1))

'''
list1 = [1, 2, 3, 4, 'dfsf', 0, 3, 3, 2]
list2 = []

for i in list1:
    if i not in list2:
        list2.append(i)

print(list2)
'''