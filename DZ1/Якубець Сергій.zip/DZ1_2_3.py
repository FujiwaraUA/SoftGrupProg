# -*- coding: utf-8 -*-
# 3. Зсув

s = 'a b c d e f'
s1 = s[-1] + ' ' + s[:-2]
